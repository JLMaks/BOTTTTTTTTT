# ⚜ République RP — Bot Discord Politique

Bot Discord complet avec créateur de personnage 3D (style GTA).
**100% GRATUIT · SANS CARTE BANCAIRE · 24h/24 7j/7**

---

## 🆓 Stack gratuite permanente

| Service | Rôle | Gratuit ? |
|---|---|---|
| **Render** | Héberge le bot + site web | ✅ Oui, sans CB |
| **Supabase** | Base de données PostgreSQL | ✅ 500MB gratuits |
| **UptimeRobot** | Anti-sleep (ping toutes les 5 min) | ✅ Gratuit |
| **GitHub** | Hébergement du code (requis par Render) | ✅ Gratuit |

---

## 🚀 Déploiement étape par étape

### Étape 1 — Créer le bot Discord

1. Allez sur https://discord.com/developers/applications
2. **New Application** → donnez un nom
3. Onglet **Bot** → **Add Bot**
4. **Reset Token** → copiez le token (ne le partagez jamais)
5. Activez : `SERVER MEMBERS INTENT` + `MESSAGE CONTENT INTENT`
6. **OAuth2 → URL Generator** :
   - Scopes : `bot` + `applications.commands`
   - Permissions : `Send Messages`, `Embed Links`, `Use Slash Commands`
7. Ouvrez l'URL générée → invitez le bot sur votre serveur

---

### Étape 2 — Base de données Supabase (gratuit, sans CB)

1. Créez un compte sur https://supabase.com (gratuit, sans CB)
2. **New Project** → choisissez un nom et une région Europe
3. Dans **Settings → Database**, copiez l'URL de connexion :
   ```
   postgresql://postgres:[MOT_DE_PASSE]@db.[REF].supabase.co:5432/postgres
   ```
4. Gardez cette URL pour l'étape 4

---

### Étape 3 — Mettre le code sur GitHub

1. Créez un compte sur https://github.com (gratuit)
2. Créez un **nouveau repository** (public ou privé)
3. Uploadez tous les fichiers de ce projet :
   - Glissez-déposez les fichiers dans l'interface GitHub
   - OU utilisez `git push` en ligne de commande

---

### Étape 4 — Déployer sur Render (gratuit, sans CB)

1. Créez un compte sur https://render.com (gratuit, sans CB)
2. **New → Web Service** → connectez votre repo GitHub
3. Paramètres :
   - **Build Command** : `pip install -r requirements.txt`
   - **Start Command** : `python app.py`
   - **Region** : Frankfurt (EU)
   - **Instance Type** : Free
4. Dans **Environment Variables**, ajoutez :
   ```
   DISCORD_TOKEN   =  votre_token_discord
   WEB_URL         =  https://VOTRE-NOM.onrender.com
   DATABASE_URL    =  votre_url_supabase
   ```
5. Cliquez **Create Web Service** → attendez le déploiement (~3 min)

---

### Étape 5 — Anti-sleep avec UptimeRobot (gratuit)

Le free tier de Render "dort" après 15 minutes d'inactivité.
UptimeRobot le ping toutes les 5 minutes pour le garder éveillé.

1. Créez un compte sur https://uptimerobot.com (gratuit)
2. **Add New Monitor** :
   - Type : **HTTP(s)**
   - URL : `https://VOTRE-NOM.onrender.com/ping`
   - Interval : **5 minutes**
3. Sauvegardez → votre bot reste **actif 24h/24** ✅

---

## 💻 Test en local

```bash
pip install -r requirements.txt
cp .env.example .env
# Éditez .env avec votre token Discord
python app.py
```

L'interface web : http://localhost:5000

---

## 📋 Commandes Discord

| Commande | Description |
|---|---|
| `/creer` | 🎨 Ouvre le créateur de personnage 3D |
| `/profil` | 👤 Affiche votre fiche de personnage |
| `/profil @membre` | 👤 Affiche la fiche d'un autre membre |
| `/fiche` | 📄 Génère la fiche texte à copier dans Discord |
| `/liste` | 📋 Liste tous les personnages du serveur |
| `/classement [compétence]` | 🏆 Classement par compétence |
| `/supprimer` | 🗑️ Supprime votre personnage |

---

## 🗂️ Structure du projet

```
republic-rp/
├── app.py          # Serveur Flask + lance le bot (entrée principale)
├── bot.py          # Bot Discord (commandes slash, embeds)
├── database.py     # BDD (SQLite en local, PostgreSQL/Supabase en prod)
├── templates/
│   ├── index.html  # Créateur 3D (Three.js, style GTA)
│   └── error.html  # Page d'erreur
├── requirements.txt
├── render.yaml     # Config déploiement Render
└── .env.example    # Variables d'environnement
```

---

## ❓ Questions fréquentes

**Le bot dort quand personne ne l'utilise ?**
UptimeRobot résout ce problème (voir Étape 5). Le bot répond en quelques secondes maximum.

**Les données sont-elles perdues si Render redémarre ?**
Non — avec Supabase, la base de données est externe et persiste toujours.

**Puis-je héberger plusieurs bots ?**
Render offre 1 service web gratuit. Pour plusieurs bots, créez plusieurs comptes.

**Mon token Discord est-il sécurisé ?**
Oui — il est stocké comme variable d'environnement sur Render, jamais dans le code.
